import React, { Component } from 'react';
function ShopB() {
    return ( 
        <div style={{marginTop: '50px'}}>
           <h1 style={{fontWeight: '600', marginLeft: '500px' }}>Shop By Category</h1>
           <p style={{marginLeft: '250px'}} >Check out our products according to the category i.e bedroom essentials, bathroom luxury, kitchen & dining, and decor items</p>

        </div>

     );
}

export default ShopB;
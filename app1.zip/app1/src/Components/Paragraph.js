import React, { Component } from 'react';
function Paragraph() {
    return ( 
      <div>
          <p style={{marginLeft: '50px', marginTop: '50px'}}>Enhance the beauty of your home and upgrade your serving style with our luxurious kitchenwares and home accessories. Be hurry to place your orders as we have limited stock </p>
          <p style={{marginLeft: '600px', marginTop: '-20px'}} >available.</p>
      </div>

     );
}


export default Paragraph;
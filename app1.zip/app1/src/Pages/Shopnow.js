function Shopnow() {
    return ( 
        <div>
            kik,kmjk,ko
        </div>
     );
}

export default Shopnow;